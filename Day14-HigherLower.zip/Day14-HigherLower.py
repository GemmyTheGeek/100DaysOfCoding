import random
import art
import game_data
from os import system

points = 0

print(art.logo)
print('Welcome to Higher or Lower! Try to guess if the person on the bottom has more or less followers.\n')

number = game_data.data[random.randint(0,len(game_data.data))]

name = number['name']
who = number['description']
country = number['country']
fol = number['follower_count']

while True:
    print(f'{name} is a {who} from {country}. They have {fol} followers.')
    print(art.vs)

    number2 = game_data.data[random.randint(0,len(game_data.data))]

    name2 = number2['name']
    who2 = number2['description']
    country2 = number2['country']
    fol2 = number2['follower_count']

    print(f'{name2} is a {who2} from {country2}. They have ___ followers.')

    horl = input(f'Does {name2} have more or less followers than {name} (M/L): ').lower()

    if horl == 'm' and fol2 > fol:
        points += 1
        system('cls')
        name = name2
        who = who2
        country = country2
        fol = fol2
        print(f'Correct! You now have {points} point(s).')
        continue
    elif horl == 'l' and fol2 < fol:
        points += 1
        system('cls')
        name = name2
        who = who2
        country = country2
        fol = fol2
        print(f'Correct! You now have {points} point(s).')
        continue
    elif horl == 'm' and fol2 < fol:
        print('You lost. Try again.')
        exit()
    elif horl == 'l' and fol2 > fol:
        print('You lost. Try again.')
        exit()
    else:
        print('Invalid Input')
        exit()

